#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void init() {
  setvbuf(stdout, 0, 2, 0);
  alarm(60);
}

void vuln_func() {
    char buf[100];
    printf("Welcome to echo service v1.08, I will print all of your input. Input:\n");
    read(0, buf, 128);
    while (strcmp(buf, "--") != 0) {
      puts(buf);
      printf("Input:\n");
      read(0, buf, 128);
    }
}

int main(int argc, char const *argv[]) {
    init();
    vuln_func();
    return 0;
}
