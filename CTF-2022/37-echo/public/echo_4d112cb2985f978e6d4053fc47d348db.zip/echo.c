#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int can_leave = 0;

void init() {
  setvbuf(stdout, 0, 2, 0);
  alarm(60);
}

void get_shell() {
    system("/bin/sh");
}

void vuln_func() {
    char buf[100];
    printf("Welcome to echo service v1.07, I will print all of your input. Input:\n");
    scanf("%s", buf);
    while (strcmp(buf, "--") != 0 || !can_leave) {
      printf(buf);
      printf("\nInput:\n");
      scanf("%s", buf);
    }
}

int main(int argc, char const *argv[]) {
    init();
    vuln_func();
    return 0;
}
