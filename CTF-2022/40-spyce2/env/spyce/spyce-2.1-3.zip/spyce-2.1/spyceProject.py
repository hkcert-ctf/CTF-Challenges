#!/usr/bin/env python

import sys, os, shutil

try:
    (target,) = sys.argv[1:]
except:
    print """spyceProject automates the creation of new Spyce projects.
Usage: spyceProject <target directory>
e.g., spyceProject /var/firstproject"""
    sys.exit()

target = os.path.abspath(target)
if os.path.exists(target):
    print "Error: %s already exists!" % target
    sys.exit()

try:
    os.makedirs(target)
except:
    print """Error creating %s.
Most likely you do not have appropriate permissions.""" % target
    sys.exit()
print '\tcreated %s' % target

for subdir in ['www', 'lib', 'login-tokens']:
    subtarget = os.path.join(target, subdir)
    os.mkdir(subtarget)
    print '\tcreated %s' % subtarget

# create _util for calendar js stuff
# (done manually instead of with shutil.copytree since we don't
# wan't to copy .svn directories if we're working from a subversion checkout.)
os.mkdir(os.path.join(target, 'www', '_util'))
for fname in os.listdir('util'):
    if fname.startswith('.'):
        continue
    src = os.path.join('util', fname)
    dst = os.path.join(target, 'www', '_util', fname)
    shutil.copy2(src, dst)

# write spyceconf
spyceconf = """
from spyceconf import *

# The root option defines the path from which Spyce requests are processed.
# I.e., when a request for http://yourserver/path/foo.spy arrives,
# Spyce looks for foo.spy in <root>/path/.
root = r'%s'
# This allows you to import .py modules from the lib directory.
sys.path.append(r'%s')

# Some commonly overridden options -- see spyceconf.py from the Spyce
# distribution for details and the full set of options.
debug = False        # True to log more to stderr
port = 8000          # webserver port
indexExtensions = ['spy'] # list of extensions to check if directory requested

# database connection
# Examples:
# db = SqlSoup('postgres://user:pass@localhost/dbname')
# db = SqlSoup('sqlite:///my.db')
# db = SqlSoup('mysql://user:pass@localhost/dbname')
#
# SqlSoup takes the same URLs as an SqlAlchemy Engine.  See 
# http://www.sqlalchemy.org/docs/dbengine.myt#dbengine_establishing
# for more examples.
db = None

# authentication -- see spyceconf.py for how to customize these
login_validator = nevervalidator
login_storage = FileStorage(r'%s')
login_render = 'render:login'
loginrequired_render = 'render:login_required'
""".strip() % (os.path.join(target, 'www'),
			   os.path.join(target, 'lib'),
			   os.path.join(target, 'login-tokens'))
configfile = os.path.join(target, 'config.py')
open(configfile, 'w').write(spyceconf)
print '\tcreated %s' % configfile

# write index skeleton
index = """
<spy:parent title="Welcome" />

Welcome to your new Spyce project!  Feel free to join
<a href=http://sourceforge.net/mailarchive/forum.php?forum_id=10008>the mailing list</a>
and ask any questions you have.
""".strip()
indexfile = os.path.join(target, 'www', 'index.spy')
open(indexfile, 'w').write(index)
print '\tcreated %s' % indexfile

# write default css
css = """
.validationerror {
  background-color: #44eeff;
}
.validationerror dt {
	font-weight: bold;
	margin-left: 1em;
	margin-top: 0.5em;
}
.validationerror dd {
	margin-left: 1em;
	margin-bottom: 0.5em;
}
""".strip()
cssfile = os.path.join(target, 'www', 'style.css')
open(cssfile, 'w').write(css)
print '\tcreated %s' % cssfile

# write parent skeleton
parent = """
<html>
  <head>
    <link rel=stylesheet href="style.css" type="text/css">
    <title>[[= child.title ]]</title>
  </head>

  <body>
    <h1>[[= child.title ]]</h1>
    <hr>

    [[= child._body ]]
    
  </body>
</html>
""".strip()
parentfile = os.path.join(target, 'www', 'parent.spi')
open(parentfile, 'w').write(parent)
print '\tcreated %s' % parentfile

# all done
print '\nSuccessfully created project skeleton at %s' % target
print '\nRun spyceCmd.py -l --conf "%s" to see it at http://localhost:8000/' % configfile
