#!/bin/sh

file=$1
line=$2

cat >> addfirstline.tmp << EOF
$line
`cat $file`
EOF

mv addfirstline.tmp $file
