#!/usr/bin/env python

# must be placed in the main spyce group directory, i.e.
# /home/groups/s/sp/spyce
# from there it sets up the environment for CGI scripts; this is
# so that we don't have
# to reconfigure the vanilla spyce distro every time we "make sf"

import sys, os.path

script = '/home/groups/s/sp/spyce/spyce/spyceCGI.py'
confpath = '/home/groups/s/sp/spyce/spyceconf-sf.py'

if __name__ == '__main__':
  sys.path.append(os.path.dirname(script))
  for arg in ['--conf', confpath]:
    sys.argv.insert(-1, arg)
  execfile(script)
