from spyceconf import *

sys.path.append('/home/groups/s/sp/spyce/modules')

tmp = '/tmp/persistent/spyce'

session_store = session.DbmStore(tmp)

login_storage = FileStorage(tmp)

check_modules_and_restart = False
