#!/usr/bin/env python

print "Content-Type: text/html"
print 
print "<html><body>"
print "Hello world! "
for i in range(10):
  print i,
print "</body></html>"
