#include <stdio.h>

int main() 
{
  int i;
  printf("Date: Sun, 26 May 2002 18:22:24 GMT\n");
  printf("Server: Apache/1.3.22 (Unix)  (Red-Hat/Linux) mod_python/2.7.6 Python/2.2\n");
  printf("Last-Modified: Sun, 26 May 2002 18:19:49 GMT\n");
  printf("ETag: \"84244-47-3cf12745\"\n");
  printf("Accept-Ranges: bytes\n");
  printf("Content-Length: 71\n");
  printf("Connection: close\n");
  printf("Content-Type: text/html\n");
  printf("\n");
  printf("<html><body>\n");
  printf("Hello world!\n");
  for(i=0; i<10; i++)
  {
    printf(" %d ", i);
  }
  printf("</body></html>\n");
  return 0;
}

