<html><body>
  Hello world!
  <?for($i=0; $i<10; $i++) { ?>
    <?echo $i?>
  <? } ?>
</html></body>
