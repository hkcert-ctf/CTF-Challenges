def formatArgs(kwargs):
  if not kwargs:
    return ''
  L = []
  for key in kwargs.keys():
    if kwargs[key] is None:
      L.append(key)
    else:
      L.append('%s="%s"' % (key, kwargs[key]))
  return ' ' + ' '.join(L)

def find_selected(tag, name, selected, default):
  if selected is None:
    selected = tag._api.getModule('request').getpost(name)
    if selected is None and default is not None:
      selected = default
    if selected is None:
      return []
  if isinstance(selected, basestring) and selected.startswith('='):
      selected = tag.eval(selected)
  if isinstance(selected, basestring) or not hasattr(selected, '__contains__'):
    selected = (selected,)
  return selected

def escape_dq(value):
  return str(value).replace('"', '\\"')

def render_radio(tagname, name, label, value, checked, id=None, kwargs=None):
  if id is None:
    id = name
  checkedstr = checked and ' CHECKED' or ''
  baseradio = '<input type="%s" name="%s" id="%s" value="%s"%s%s>' \
      % (tagname, name, id, escape_dq(value), checkedstr, formatArgs(kwargs))
  if label is not None:
    baseradio += '<label for="%s">%s</label> ' % (id, label)
  return baseradio
    
def render_option(value, text, selected):
  if selected:
    selectedtxt = ' selected'
  else:
    selectedtxt = ''
  return '<option value="%s"%s>%s</option>' % (escape_dq(value), selectedtxt, text)

def maybe_emit_label(tag, id, label):
  if label is not None:
    tag.getOut().write('<label for="%s">%s</label> ' % (id, label))
