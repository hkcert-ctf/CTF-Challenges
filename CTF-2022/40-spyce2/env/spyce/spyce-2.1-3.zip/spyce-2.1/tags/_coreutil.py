import cPickle as pickle
import spyceUtil, spyceLock
from spyceModule import moduleFinder
from session import newtoken

def logout(api):
    api.cookie.delete('_spy_login')
    api.redirect.external(api.request.uri())
    api.response.end()

def login_from_cookie(request):
    import sys
    sys.stderr.write('_cookie!')
    from spyceConfig import login_storage
    cookie = request._api.getModule('cookie')
    if '_spy_login' in cookie:
      uid, token = pickle.loads(cookie['_spy_login'])
      if login_storage.validate(uid, token):
        return uid
    return None

def login_stub(request, validator, login, password, rememberme=False):
    try:
        uid = validator(login, password)
    except TypeError:
        raise 'invalid login_validator function in spyceconf'
    if uid is not None:
      from spyceConfig import login_storage
      mf = moduleFinder(request._api)
      token = newtoken(mf)
      login_storage.set(uid, token)
      if rememberme:
          expires = 3600 * 24 * 365 * 10 # 10 years
      else:
          expires = None
      mf.cookie.set('_spy_login', pickle.dumps((uid, token)), expires)
    return uid

def login_perform(request, validator):
    return login_stub(request, validator, 
                      request.getpost1('_spy_login_user'),
                      request.getpost1('_spy_login_password'),
                      request.getpost1('_spy_login_rememberme'))

def login_pending(request):
    return request.getpost('_spy_login_user')

# storage objects must have "set" and "validate" methods
# with the signatures demonstrated here.
class FileStorage:
    def __init__(self, path):
        self.path = path
    def set(self, uid, token):
        p = self._path(uid)
        L = FileStorage._getLock(p)
        L.acquire()
        try:
            open(p, 'w').write(token)
        finally:
            L.release()
    def validate(self, uid, token):
        p = self._path(uid)
        L = FileStorage._getLock(p)
        L.acquire()
        try:
            try:
                return token == open(p).read()
            except IOError:
                return False
        finally:
            L.release()
    def _path(self, uid):
        import spyce, os.path
        return os.path.join(self.path, 'spytoken-%s' % uid)
    # cache locks for speed
    locks = {}
    def _getLock(cls, path):
        # it's okay if we generate multiple locks for the same path
        # so we don't bother with thread-level locking here
        if path not in FileStorage.locks:
            FileStorage.locks[path] = spyceLock.fileLock(path)
        return FileStorage.locks[path]
    _getLock = classmethod(_getLock)
