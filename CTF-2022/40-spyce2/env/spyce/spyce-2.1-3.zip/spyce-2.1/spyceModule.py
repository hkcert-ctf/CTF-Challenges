##################################################
# SPYCE - Python-based HTML Scripting
# Copyright (c) 2002 Rimon Barr.
#
# Refer to spyce.py
##################################################

__doc__ = '''Spyce modules functionality.'''

##################################################
# Spyce module
#

class spyceModule:
  "All Spyce module should subclass this."
  def __init__(self, wrapper):
    self._api = wrapper
  def start(self):
    # called by spyce.py to initialize module
    pass
  def finish(self, theError=None):
    # called by spyce.py to clean up
    pass
  def init(self, *args, **kwargs):
    # called from compiled spyceProcess
    pass
  def __repr__(self):
    return 'no information, '+str(self.__class__)

class spyceModulePlus(spyceModule):
  def __init__(self, wrapper):
    spyceModule.__init__(self, wrapper)
    self.wrapper = self._api  # deprecated
    self.modules = moduleFinder(wrapper)
    self.globals = wrapper.getGlobals()

from code import InteractiveConsole
import sys
class BreakpointConsole(InteractiveConsole):
    def __init__(self, locals):
        InteractiveConsole.__init__(self, locals, 'bpconsole')
        from spyceConsole import DummyWriter
        sys.stdout = DummyWriter(sys.__stdout__, sys.stdout, 'bpconsole')
        sys.stderr = DummyWriter(sys.__stderr__, sys.stderr, 'bpconsole')
    def __del__(self):
        sys.stdout = sys.stdout.other_stream
        sys.stderr = sys.stderr.other_stream
        
    def raw_input(self, prompt=''):
        self.write(prompt)
        s = raw_input().rstrip()
        s = s.rstrip()
        if not s or s == 'continue':
          raise EOFError()
        return s

# this is what gets passed to handlers as "api"
class moduleFinder:
  def __init__(self, wrapper):
    self._wrapper = wrapper
  def db(self):
    return self._wrapper._codeenv.db
  db = property(db)
  def breakpoint(self, locals=None):
    # (convenience method for active handlers)
    if locals is None:
      import sys
      locals = sys._getframe(1).f_locals
    import threading
    th = threading.currentThread()
    old_name = th.getName()
    try:
      th.setName('bpconsole')
      bc = BreakpointConsole(locals)
      sys.stdout.write('Spyce breakpoint console: type "continue" (without the quotes) to exit\n')
      bc.interact()
    finally:
      th.setName(old_name)
  def __repr__(self):
    return 'moduleFinder'
  def __getattr__(self, name):
    return self._wrapper.getModule(name)

##################################################
# Spyce module API
#

spyceModuleAPI = [ 'getFilename', 'getCode', 
  'getCodeRefs', 'getModRefs', 
  'getServerObject', 'getServerGlobals', 'getServerID',
  'getModules', 'getModule', 'setModule', 'getGlobals', 
  'registerModuleCallback', 'unregisterModuleCallback',
  'getRequest', 'getResponse', 'setResponse',
  'registerResponseCallback', 'unregisterResponseCallback', 
  'spyceString', 'spyceFile', 'spyceModule', 'spyceTaglib',
  'setStdout', 'getStdout',
]

