##################################################
# SPYCE - Python-based HTML Scripting
# Copyright (c) 2002 Rimon Barr.
#
# Refer to spyce.py
##################################################

from spyceModule import spyceModule
import re
import spyce, spyceUtil

__doc__ = """Include module is used to assist the inclusion of abitrary
elements/files into a Spyce file. It can also support the notion of an
'inclusion context'."""

class include(spyceModule):
  def start(self):
    self.context = None
    self.vars = None
  def spyce(self, url, context=None):
    "Include a Spyce file"
    spyce.DEBUG('including ' + url)
    if len(self._api.getStack()) >= spyce.MAX_STACK:
      raise 'Maximum stack depth exceeded! (infinite include loop?)'
    filename = spyceUtil.url2file(url, self._api.getFilename())
    result = s = code = None
    try:
      code = self._api.spyceFile(filename)
      s = code.newWrapper()
      modules = self._api.getModules()
      for name in modules.keys():
        s.setModule(name, modules[name])  # include module as well!
      s.spyceInit(self._api.getRequest(), self._api.getResponse())
      incmod = s._startModule('include', None, None, 1)
      incmod.context = context
      if type(context)==type({}):
        incmod.vars = spyceVars(context)
      self._api.getStack().append(filename)
      result = s.spyceProcess()
      self._api.getStack().pop()
    finally:
      if s:
        s.spyceDestroy()
        code.returnWrapper(s)
    return result
  def spyceStr(self, url, context=None):
    stdout = self._api.getModule('stdout')
    stdout.push()
    try:
      result = self.spyce(url, context)
    finally:
      output = stdout.pop()
    return output
  def dump(self, file, binary=0):
    "Include a plain text file, verbatim"
    file = os.path.join(os.path.dirname(self._api.getFilename()), file)
    f = None
    try:
      if binary: mode='rb'
      else: mode='r'
      f = open(file, mode)
      buf = f.read()
    finally:
      if f: f.close()
    return buf
  def spycecode(self, url=None, string=None, html=None, code=None, eval=None, directive=None, comment=None, tag=None):
    "Emit formatted Spyce code"
    if not html: html = ('<font color="#000000"><b>', '</b></font>')
    if not code: code = ('<font color="#0000CC">', '</font>')
    if not eval: eval = ('<font color="#CC0000">', '</font>')
    if not directive: directive = ('<font color="#CC00CC">', '</font>')
    if not comment: comment = ('<font color="#ff7448">', '</font>')
    if not tag: tag = ('<font color="#229922">', '</font>')
    import spyceCompile
    from StringIO import StringIO
    if (url and string) or (not url and not string):
      raise 'must specify either url or string, and not both'
    if url:
      f = None
      try:
        filename = spyceUtil.url2file(url, self._api.getFilename())
        f = open(filename, 'r')
        string = f.read()
      finally:
        if f: f.close()
    html_encode = self._api.getModule('transform').html_encode
    try:
      tokens = spyceCompile.spyceTokenize(string)
      buf = StringIO()
      markupstack = []
      buf.write(html[0]); markupstack.append(html[1])
      for type, text, _, _ in tokens:
        if type == spyceCompile.T_TEXT:
          while True:
            m = spyceCompile.RE_LIB_TAG.search(text)
            if not m:
              buf.write(html_encode(text))
              break
            pre = text[:m.start()]
            post = text[m.end():]
            buf.write(html_encode(pre))
            buf.write(tag[0])
            buf.write(html_encode(m.group(0)))
            buf.write(tag[1])
            text = post
          continue

        if type in (spyceCompile.T_STMT, spyceCompile.T_CHUNK, spyceCompile.T_CHUNKC,):
          buf.write(code[0]); markupstack.append(code[1])
        elif type in (spyceCompile.T_LAMBDA,):
          buf.write(html[0]); markupstack.append(html[1])
        elif type in (spyceCompile.T_EVAL,):
          buf.write(eval[0]); markupstack.append(eval[1])
        elif type in (spyceCompile.T_DIRECT,):
          buf.write(directive[0]); markupstack.append(directive[1])
        elif type in (spyceCompile.T_CMNT,):
          buf.write(comment[0]); markupstack.append(comment[1])
        buf.write(html_encode(text))
        if type in (spyceCompile.T_END_CMNT, spyceCompile.T_END,):
          buf.write(markupstack.pop())
      while markupstack:
        buf.write(markupstack.pop())
      return buf.getvalue()
    except:
      raise
      raise 'error tokenizing!'

class spyceVars:
  def __init__(self, vars):
    self.__dict__['vars'] = vars
  def __getattr__(self, name):
    try: return self.__dict__['vars'][name]
    except KeyError: raise AttributeError
  def __setattr__(self, name, value):
    self.__dict__['vars'][name] = value

