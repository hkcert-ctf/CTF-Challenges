from spyceModule import spyceModule

class myModule(spyceModule):
  def foo(self):
    print 'foo called'

