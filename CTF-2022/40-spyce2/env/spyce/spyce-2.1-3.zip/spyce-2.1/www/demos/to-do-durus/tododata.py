# this file extends contrib/spydurus.py, a connection-pooling Spyce module
# for Durus, with a convenience method specific to the to-do Durus database

import os
import spydurus
from durus.persistent_dict import PersistentDict

import spyce
durus_path = os.path.join(spyce.getServer().config.tmp, 'todo.durus')

spydurus.maybeStartDurus(durus_path)
spydurus.initPool(db_path=durus_path)

# initialize listroot if it's a brand-new database
conn = spydurus.q.get()
try:
    conn.get_root()['lists']
except KeyError:
    conn.get_root()['lists'] = PersistentDict()
    conn.commit()
spydurus.q.put(conn)

class tododata(spydurus.spydurus):
    def listroot(self):
        return self.root()['lists']
