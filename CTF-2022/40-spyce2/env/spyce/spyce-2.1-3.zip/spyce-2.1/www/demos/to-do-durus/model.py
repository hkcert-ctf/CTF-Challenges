from durus.persistent_list import PersistentList
from spydurus import PersistentWithId
from spyceException import HandlerError

# model
class TodoList(PersistentWithId):
    def __init__(self, description):
        self.items = PersistentList()
        self.description = description

class TodoItem(PersistentWithId):
    def __init__(self, parent, description):
        self.description = description
        self.done = False
        parent.items.append(self)


# handler actions for index
def list_new(api, description):
    data = api.data
    if description in data.listroot():
        raise HandlerError('New list', 'a list with that description already exists')
    todo = TodoList(description)
    data.listroot()[description] = todo
    data.commit()
    api.redirect.external('list-view.spy?todoid=%s' % todo.id())
    api.response.end()

def list_delete(api, todoid):
    data = api.data
    for id in todoid:
        todo = data.get(id)
        del data.listroot()[todo.description]
    data.commit()


# handler actions for list-view
def list_edit(api, todoid, description):
    data = api.data
    if description in data.listroot():
        raise HandlerError('Description', 'a list with that description already exists')
    todo = data.get(todoid)
    # we use the listroot() dict to prevent duplicate todo descriptions
    # so we need to remove the old hash entry and add a new one
    del data.listroot()[todo.description]
    todo.description = description
    data.listroot()[todo.description] = todo
    data.commit()

def item_new(api, todoid, description):
    todo = api.data.get(todoid)
    item = TodoItem(todo, description)
    api.data.commit()

def item_markdone(api, item_ids=None):
    if not item_ids:
        raise HandlerError('Items', 'None selected')
    for id in item_ids:
        item = api.data.get(id)
        item.done = True
    api.data.commit()
