from spyceException import HandlerError

# handler actions for index
def list_new(api, name):
    if api.db.todo_lists.selectfirst_by(name=name):
        raise HandlerError('New list', 'a list with that description already exists')
    todo = api.db.todo_lists.insert(name=name)
    api.db.flush()
    api.redirect.external('list-view.spy?todoid=%s' % todo.list_id)
    api.response.end()

def list_delete(api, todoid):
    lists = api.db.todo_lists
    lists.delete(lists.c.id.in_(*todoid))


# handler actions for list-view
def list_edit(api, todoid, name):
    todo = api.db.todo_lists.selectfirst_by(name=name)
    if todo and todo.list_id != todoid:
        raise HandlerError('New list', 'a list with that description already exists')
    todo = api.db.todo_lists.selectone_by(list_id=todoid)
    todo.name = name
    api.db.flush()

def item_new(api, todoid, description):
    todo = api.db.todo_items.insert(list_id=todoid, description=description)
    api.db.flush()

def item_markdone(api, item_ids=None):
    if not item_ids:
        raise HandlerError('Items', 'None selected')
    items = api.db.todo_items
    items.update(items.c.item_id.in_(*item_ids), done=1)
