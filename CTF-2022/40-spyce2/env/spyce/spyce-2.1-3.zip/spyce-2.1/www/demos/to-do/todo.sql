CREATE TABLE todo_lists (
    list_id              integer PRIMARY KEY, -- int PK automatically autonumbered by sqlite
    name                 varchar(256) NOT NULL
);

CREATE TABLE todo_items (
    item_id             integer PRIMARY KEY, -- int PK automatically autonumbered by sqlite
    list_id             integer NOT NULL REFERENCES todo_lists(list_id),
    description         varchar(256) NOT NULL,
    done                integer NOT NULL DEFAULT 0
);
