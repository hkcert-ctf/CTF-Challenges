from __future__ import generators
import cgi
import sys
import keyword
import token
import tokenize

def prettyhtml(fd):
    return """
<style>    
.STRING {
  color: #a0522d;
}
.COMMENT {
  color: #ff7448;
  font-family: serif;
}
.KEYWORD {
  color: #9e79af;
}
.FUNCTION {
  color: #0074ef;
}
</style>
<pre>
%s
</pre>
    """ % ''.join(list(prettyprint(fd)))

def prettyprint(fd):
    """Pretty print code into HTML/CSS.

    This returns a generator, which generates tokens to be printed to
    some HTML document.  You'll need to define a style sheet to get the
    colors you like.

    """
    
    end = (0, 0)
    last = (None,) * 5
    for tok in tokenize.generate_tokens(fd.readline):
        start = tok[2]
        if start[1] != end[1]:
            if start[0] != end[0]:
                # What to do here?  Punt.
                yield '\n<strong>prettyprint punting: %s %s</strong>\n' % (tok, end)
            else:
                yield tok[4][end[1]:start[1]]
        end = tok[3]
        if end[1] == len(tok[4]):
            # Prevent punting on newlines
            end = (end[0] + 1, 0)
        if tok[0] == token.NAME:
            if keyword.iskeyword(tok[1]):
                style = 'KEYWORD'
            elif last[1] in ('class', 'def'):
                style = 'FUNCTION'
            else:
                style = 'NAME'
        else:
            style = token.tok_name.get(tok[0])
        s = tok[1].expandtabs()
        txt = cgi.escape(s)
        if style:
            last = tok
            yield ('<span class="%s">%s</span>'
                   % (style, txt))
        else:
            yield s
