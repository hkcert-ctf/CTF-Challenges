Contents of contrib/:

File                               What                            Author

jedit-spyce.xml             jEdit spyce syntax                    Marius Scurtescu
kate-spyce.xml              Kate spyce syntax                     Jeffery Reavis
spyce.el                    Emacs spyce mode                      Jonathan Ellis
spyce.vim                   VIM spyce syntax                      Rimon Barr


xitami/                     LWRP connector for Xitami             Jim Madsen


modules/                    spyce modules

        automaton.*         state machine module                  Rimon Barr
        etag.py             cgi_buffer functionality              Francisco Cabello
        mail.*              mail functionality                    Adrien Plisson
        spydurus.py         Durus connection pooling              Jonathan Ellis
        template.py         Cheetah interface                     Rimon Barr
        toc.py              table-of-contents module              Rimon Barr


tags/                       spyce active tags

     flow.py                flow-control tags                     Rimon Barr


pyweboff/                   demo app; see                         Jonathan ellis
                            http://www.third-bit.com/pyweb/index.html
                            for description of "The Challenge"
                            run with "spyceCmd -l --conf contrib/pyweboff/config.py"
