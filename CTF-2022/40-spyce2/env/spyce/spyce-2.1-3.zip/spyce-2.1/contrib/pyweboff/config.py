from spyceconf import *

# The root option defines the path from which Spyce requests are processed.
# I.e., when a request for http://yourserver/path/foo.spy arrives,
# Spyce looks for foo.spy in <root>/path/.
PYWEBOFF_HOME = os.path.abspath(os.path.split(__file__)[0])
root = os.path.join(PYWEBOFF_HOME, 'www')
# This allows you to import .py modules from the lib directory.
sys.path.append(os.path.join(PYWEBOFF_HOME, 'lib'))

# Some commonly overridden options -- see spyceconf.py from the Spyce
# distribution for details and the full set of options.
port = 8001          # webserver port
indexExtensions = ['spy'] # list of extensions to check if directory requested

#### pyweboff config ####
db = SqlSoup('sqlite:///%s' % os.path.join(PYWEBOFF_HOME, 'pyweboff.db'))

# admin login is "Bhargan Basepair", "basepair"
def validator(login, password):
    L = db.users.select_by(name=login, password=password)
    if L:
        return login
    return None
def admin_validator(login, password):
    L = db.users.select_by(name=login, password=password, admin=True)
    if L:
        return login
    return None
login_defaultvalidator = validator
login_storage = FileStorage(os.path.join(PYWEBOFF_HOME, 'login-tokens'))
