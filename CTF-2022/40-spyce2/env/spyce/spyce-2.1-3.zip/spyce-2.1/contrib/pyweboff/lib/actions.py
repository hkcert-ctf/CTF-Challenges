from spyceConfig import db

def book_loan(api, user_name, books):
    for book_id in books:
        db.loans.insert(user_name=user_name, book_id=book_id)
    db.flush()

def book_return(api, books):
    for book_id in books:
        loan = db.loans.selectone_by(book_id=book_id)
        db.delete(loan)
    db.flush()

def user_new(api, name, email, password, classname, admin):
	u = db.users.insert(name=name, email=email, password=password, classname=classname, admin=admin)
	u.admin = admin
	db.flush()
	api.redirect.external('/')
	api.response.end()
