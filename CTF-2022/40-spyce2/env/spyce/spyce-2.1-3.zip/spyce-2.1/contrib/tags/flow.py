from spyceTag import spyceTagLibrary, spyceTagPlus

# use of these tags is deprecated; they will be removed in a future version of Spyce

# These tags are modeled after some of the functionality that exists in Java's
# <a href=http://java.sun.com/products/jsp/jstl/>JSTL</a>. However, with Spyce,
# it's simpler and cleaner to just embed python statements. The cumbersome
# nature of using Java code directly inside JSP makes the JSTL make sense for
# J2EE users; there's no real need for the same in Spyce, but these are
# available for those who avoid Python in "view" code for religions reasons.

# < print val=expression [encode=url|html] [default=expression] />
# Outputs the value of the "val" expression. If there is an error
# and a "default" is provided, the default will be evaluated instead. The
# output may be encoded to be HTML- or URL-safe, depending on the
# "encode" attribute

# < let var=expression val=expression /> [exports *var]
# Sets the variable "var" to the value "val".

# < if test=expression>...</if>
# Evaluate "test" and conditionally process body of tag.

# < for items=expression [var=expr (item)] [counter=expr]>...</for>
# [exports *var, *counter]
# Iterate through "items" and process the body each time. The current
# item can optionally be stored in variable named by "var", and the
# current iteration number (starting at zero) can optionally be stored
# in a variable named by "counter".

class tag_print(spyceTagPlus):
  name = 'print'
  def syntax(self):
    self.syntaxSingleOnly()
    self.syntaxNonEmpty('val')
    self.syntaxValidSet('encode', ['false', 'url', 'html'])
  def begin(self, val, encode='html', default=None):
    try: out = str(val)
    except: 
      if default:
        out = str(default)
      else:
        raise
    if encode == 'html':
      out = self.getModule('transform').html_encode(out)
    elif encode == 'url':
      out = self.getModule('transform').url_encode(out)
    self.getOut().write(out)

class tag_let(spyceTagPlus):
  name = 'let'
  exports = 1
  def syntax(self):
    self.syntaxSingleOnly()
    self.syntaxNonEmpty('var')
  def begin(self, var, val):
    self.var = var
    self.val = val
  def export(self):
    return {self.var: self.val}

class tag_if(spyceTagPlus):
  name = 'if'
  conditional = 1
  def syntax(self):
    self.syntaxPairOnly()
  def begin(self, test, var=None):
    return test

# rimtodo: add first, last boolean flag variables
class tag_for(spyceTagPlus):
  name = 'for'
  conditional = 1
  loops = 1
  exports = 1
  def syntax(self):
    self.syntaxPairOnly()
    self.syntaxNonEmpty('items', 'var', 'counter')
  def body(self, _contents):
    return self._iter()
  def begin(self, items, var='item', counter=None):
    self.remaining = items
    try: self.remaining = list(self.remaining)
    except TypeError:
      raise 'items expression should result in sequence, %s is not iterable'%repr(self.remaining)
    self.var = var
    self.counter = counter
    self.i = 0
    return self._iter()
  def export(self):
    d = {}
    if self.var:
      try:
        d[self.var] = self.element
      except: pass
    if self.counter:
      d[self.counter] = self.i
    return d

  def _iter(self):
    # get next
    if not self.remaining: return 0
    self.element, self.remaining = self.remaining[0], self.remaining[1:]
    self.i = self.i + 1
    return 1


# rimtodo: catch
# rimtodo: choose, when, otherwise

class flow(spyceTagLibrary):
  tags = [
    tag_print,
    tag_let, 
    tag_if,
    tag_for,
  ]
