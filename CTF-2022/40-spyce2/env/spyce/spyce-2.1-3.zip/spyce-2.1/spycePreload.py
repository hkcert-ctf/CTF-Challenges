import sys, os.path, imp

def guessSpyceHome():
  try:
    fname = sys.modules['__main__'].__file__
  except:
    # for mod_python
    fname = sys.modules['run_spyceModpy'].__file__
  bestguess = os.path.abspath(os.path.dirname(fname))
  for p in [bestguess] + sys.path:
    path = os.path.join(p, 'spyce.py')
    if os.path.exists(path):
      return os.path.abspath(p)
  raise 'unable to determine Spyce home directory; please add it to your PYTHONPATH'

def defaultConfigFile():
  return os.path.join(guessSpyceHome(), 'spyceconf.py')

def getConfigModule(configFile=None):
  if not configFile: configFile = defaultConfigFile()
  try: f = open(configFile)
  except: raise Exception('Unable to read configuration file at ' + configFile)
  try:
    mod = imp.load_module('spyceConfig', f, configFile, ('.py', 'r', imp.PY_SOURCE))
    mod.__file__ = configFile # for user-friendly error messages
    return mod
  finally: f.close()
