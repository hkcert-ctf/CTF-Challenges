# quick-and-dirty spyce debugging harness

import spyceconf
import sys
import spyce

import taglib as t

class response_stub:
    def writeStatic(self, s):
        print s
    def writeExpr(self, s):
        print s

response = response_stub()

class wrapper_stub:
    def spyceTaglib(self, name, file=None, rel_file=None):
        "Return Spyce taglib class"
        return spyce.getServer(spyceconf).loadModule(name, file, rel_file)
    def registerModuleCallback(self, callback):
        pass
    def getFilename(self):
        return 'debugstub'
    def getModules(self):
        return {'response': response,
                'stdout': sys.stdout}

taglib = t.taglib(wrapper_stub())
taglib.start()

# paste compiled Spyce here

test = spyceImpl()
test.spyceProcess()
